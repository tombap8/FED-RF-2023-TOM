// 하단영역 컴포넌트

export function FooterArea(){
    return(
        <footer className="info">
            All Site Content © &amp; TM DC, unless otherwise noted here.
            <br />
            All rights reserved.
        </footer>
    )

} ///////// FooterArea 컴포넌트 /////////