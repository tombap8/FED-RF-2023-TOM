// CGV PJ 메인 페이지 JS - main.js

// 요소선택함수 ////////
const qs = (x) => document.querySelector(x);
const qsa = (x) => document.querySelectorAll(x);
